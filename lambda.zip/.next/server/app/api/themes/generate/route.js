"use strict";(()=>{var a={};a.id=614,a.ids=[614],a.modules={261:a=>{a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:a=>{a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:a=>{a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},25528:(a,b,c)=>{c.d(b,{U:()=>g,r:()=>h});var d=c(73832),e=c(25906),f=c(1536);async function g(){let a=await (0,e.UL)();return(0,d.R)("https://foufqkcbufijlbdhfidz.supabase.co","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZvdWZxa2NidWZpamxiZGhmaWR6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODkyNDIzMjUsImV4cCI6MjEwNDgxODMyNX0.9zbnHQw6njL9_-CfaG50DhTIJySC8KtD1SJuZUyMatI",{cookies:{get:b=>a.get(b)?.value,set(b,c,d){try{a.set({name:b,value:c,...d})}catch{}},remove(b,c){try{a.set({name:b,value:"",...c})}catch{}}}})}async function h(){let a=process.env.SUPABASE_SERVICE_ROLE_KEY;return a?(0,f.UU)("https://foufqkcbufijlbdhfidz.supabase.co",a):g()}},29294:a=>{a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},37178:(a,b,c)=>{c.r(b),c.d(b,{handler:()=>E,patchFetch:()=>D,routeModule:()=>z,serverHooks:()=>C,workAsyncStorage:()=>A,workUnitAsyncStorage:()=>B});var d={};c.r(d),c.d(d,{POST:()=>y});var e=c(47736),f=c(637),g=c(19724),h=c(23582),i=c(19908),j=c(261),k=c(55410),l=c(57296),m=c(47600),n=c(83747),o=c(61629),p=c(75855),q=c(71825),r=c(73334),s=c(86439),t=c(72924),u=c(98257),v=c(25528),w=c(86247),x=c(34182);async function y(a){let b=await (0,x.v_)(a);if(b)return b;try{let b=a.headers.get("authorization"),c=process.env.CRON_SECRET;if(c&&b!==`Bearer ${c}`)return u.NextResponse.json({error:"Unauthorized"},{status:401});let d=await a.json().catch(()=>({})),e=d.language||"zh",f=d.difficulty||"Beginner";if(!["zh","de"].includes(e))return u.NextResponse.json({error:"Invalid language"},{status:400});let g=function(a,b){let c="zh"===a?"Mandarin Chinese":"German",d="zh"===a?`CHINESE-SPECIFIC REQUIREMENTS:
- Include pinyin with tone numbers (1-4) for ALL Chinese words
- Mark neutral tone as 0
- For vocabulary: provide character, pinyin, tone, translation, part of speech
- For practice sentences: Chinese characters + pinyin + English
- Common mistakes should include tone errors, word order, measure words
- Cultural notes: mention relevant Chinese customs/etiquette`:`GERMAN-SPECIFIC REQUIREMENTS:
- Include phonetic pronunciation guide for German words
- For vocabulary: provide German word (with article der/die/das), phonetic, translation, part of speech, gender
- For practice sentences: German + phonetic + English
- Common mistakes should include gender, case (nominative/accusative/dative), verb position, separable verbs
- Cultural notes: mention relevant German customs/formality`;return`You are an expert language curriculum designer creating a daily practice theme for ${c} learners at ${b} level.

${"Beginner"===b?"Use simple, high-frequency vocabulary. Keep sentences short (4-8 words). Focus on present tense and basic sentence patterns.":"Use intermediate vocabulary with some variety. Include past tense, modal verbs, and slightly longer sentences (8-12 words)."}
${d}

GENERATE A COMPLETE THEME as valid JSON with this exact structure:

{
  "title": "Short, engaging theme title (max 40 chars)",
  "description": "2-3 sentence description of what learners will practice",
  "difficulty": "${b}",
  "learningObjectives": [
    "Can-do statement 1",
    "Can-do statement 2", 
    "Can-do statement 3",
    "Can-do statement 4"
  ],
  "keyVocabulary": [
    {
      "word": "word in ${c}",
      "romanization": "pinyin/phonetic",
      "translation": "English meaning",
      "partOfSpeech": "noun/verb/adjective/etc",
      "tone": 1,
      "audioHint": "pronunciation tip"
    }
  ],
  "cues": [
    {
      "id": "cue-1",
      "order": 1,
      "title": "Short cue title",
      "description": "What this cue practices",
      "scenario": "Role-play setup in English",
      "targetLanguage": "Phrase in ${c}",
      "romanization": "pinyin/phonetic",
      "translation": "English meaning",
      "keyVocabulary": ["vocab-word-1", "vocab-word-2"],
      "difficulty": "easy",
      "tips": ["Tip 1", "Tip 2"]
    }
  ],
  "practiceSentences": [
    {
      "text": "Sentence in ${c}",
      "romanization": "pinyin/phonetic",
      "translation": "English",
      "difficulty": "easy"
    }
  ],
  "commonMistakes": [
    {
      "incorrect": "Wrong form",
      "correct": "Right form",
      "romanization": "pinyin/phonetic",
      "explanation": "Why it's wrong",
      "tip": "Memory aid"
    }
  ],
  "culturalNotes": "Optional cultural context"
}

REQUIREMENTS:
- 8-12 vocabulary items
- 4-6 progressive cues (easy → medium → hard)
- 4-6 practice sentences
- 3-4 common mistakes
- For Chinese: ALL vocabulary MUST have tone (1-4 or 0)
- For German: ALL vocabulary MUST have gender (der/die/das)
- Cues should progress logically (greeting → main interaction → closing)
- Return ONLY valid JSON, no markdown, no extra text`}(e,f),h=await (0,w.PH)({messages:[{role:"user",content:g}],language:e,context:{},forceQuality:!0}),i=function(a){try{let b=a.replace(/```json\n?/g,"").replace(/```\n?/g,"").trim(),c=JSON.parse(b);if(!c.title||!c.cues||!Array.isArray(c.cues))return console.error("Invalid theme response: missing required fields"),null;return c}catch(a){return console.error("Failed to parse theme response:",a),null}}(h.content);if(!i)return console.error("Failed to parse theme:",h.content),u.NextResponse.json({error:"Failed to parse generated theme",modelUsed:h.modelUsed},{status:500});let j=function(a){let b=[];return(!a.title||a.title.length>50)&&b.push("Title missing or too long"),(!a.keyVocabulary||a.keyVocabulary.length<8)&&b.push("Need at least 8 vocabulary items"),(!a.cues||a.cues.length<4)&&b.push("Need at least 4 cues"),(!a.practiceSentences||a.practiceSentences.length<4)&&b.push("Need at least 4 practice sentences"),(!a.commonMistakes||a.commonMistakes.length<3)&&b.push("Need at least 3 common mistakes"),{valid:0===b.length,errors:b}}(i);if(!j.valid)return console.error("Theme validation failed:",j.errors),u.NextResponse.json({error:"Generated theme failed validation",errors:j.errors},{status:500});let k=await (0,v.U)();await k.from("themes").update({is_daily:!1,updated_at:new Date().toISOString()}).eq("language",e).eq("is_daily",!0);let{data:l,error:m}=await k.from("themes").insert({title:i.title,description:i.description,language:e,difficulty:i.difficulty,content:i,is_daily:!0,generated_at:new Date().toISOString()}).select().single();if(m)return console.error("Supabase insert error:",m),u.NextResponse.json({error:"Failed to save theme",details:m.message},{status:500});return u.NextResponse.json({success:!0,theme:{id:l.id,title:l.title,description:l.description,language:l.language,difficulty:l.difficulty,is_daily:l.is_daily,generated_at:l.generated_at},modelUsed:h.modelUsed,latencyMs:h.latencyMs})}catch(a){return console.error("Theme generation error:",a),u.NextResponse.json({error:a instanceof Error?a.message:"Unknown error"},{status:500})}}let z=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/themes/generate/route",pathname:"/api/themes/generate",filename:"route",bundlePath:"app/api/themes/generate/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"/workspaces/default/code/src/app/api/themes/generate/route.ts",nextConfigOutput:"standalone",userland:d}),{workAsyncStorage:A,workUnitAsyncStorage:B,serverHooks:C}=z;function D(){return(0,g.patchFetch)({workAsyncStorage:A,workUnitAsyncStorage:B})}async function E(a,b,c){var d;let e="/api/themes/generate/route";"/index"===e&&(e="/");let g=await z.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:x,prerenderManifest:y,routerServerContext:A,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,resolvedPathname:D}=g,E=(0,j.normalizeAppPath)(e),F=!!(y.dynamicRoutes[E]||y.routes[D]);if(F&&!x){let a=!!y.routes[D],b=y.dynamicRoutes[E];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let G=null;!F||z.isDev||x||(G="/index"===(G=D)?"/":G);let H=!0===z.isDev||!F,I=F&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:y,renderOpts:{experimental:{cacheComponents:!!w.experimental.cacheComponents,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>z.onRequestError(a,b,d,A)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>z.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&B&&C&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!F)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await z.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})},A),b}},l=await z.handleResponse({req:a,nextConfig:w,cacheKey:G,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:y,isRoutePPREnabled:!1,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,responseGenerator:k,waitUntil:c.waitUntil});if(!F)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",B?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),x&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&F||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(b instanceof s.NoFallbackError||await z.onRequestError(a,b,{routerKind:"App Router",routePath:E,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})}),F)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},44870:a=>{a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:a=>{a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},86439:a=>{a.exports=require("next/dist/shared/lib/no-fallback-error.external")}};var b=require("../../../../webpack-runtime.js");b.C(a);var c=b.X(0,[783,366,315,676],()=>b(b.s=37178));module.exports=c})();